/*///<reference types="cypress" />  */

describe('Invoke test suite', () => {   
    it('invoke methods', () => {
        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Form Layouts').click()

        //1
        cy.get('[for="exampleInputEmail1"]').should('contain','Email address')

        //2
        cy.get('[for="exampleInputEmail1"]').then(label => {
            expect(label.text()).to.equal('Email address')
        })

        //3
        cy.get('[for="exampleInputEmail1"]').invoke('text').then(text => {
            expect(text).to.equal('Email address')
        })

        //invoke to verify checkbox selection
        cy.contains('nb-card','Basic form')
          .find('nb-checkbox')
          .click()
          .find('.custom-checkbox')
          .invoke('attr','class')
         // .should('contain','checked')    //one way to assert
         // .then(classVal => {
             .then(function(classVal) {
              expect(classVal).to.contains('checked')
          })
    })
})
