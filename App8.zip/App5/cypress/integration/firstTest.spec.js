/*///<reference types="cypress" />  */

describe('Our first suite', () => {

   

    it('first test', () => {

        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Form Layouts').click()

        //search element by tag name
        cy.get('input')

        //search by id

        cy.get('#inputEmail1')

        //search by class name
        cy.get('.input-full-width')

        //search by attribute name
        cy.get('[placeholder]')

        //search by attribute name and value
        cy.get('[placeholder="Email"]')

        //search by class value
        cy.get('[class="input-full-width size-medium shape-rectangle"]')

        //search by Tag name and Attribute with value
        cy.get('input[placeholder="Email"]')

        //search by multiple different attributes
        cy.get('[placeholder="Email"][type="Email"][fullwidth]')

        //search by tagname, attribute with value, ID and classname
        cy.get('input[placeholder="Email"]#inputEmail1.input-full-width')

        //recommended search by cypress - by your own id
      //  cy.get('[data-cy="inputEmail1"]')
    })

    it('second test', () => {

        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Form Layouts').click()
        cy.get('[data-cy="SignInButton"]')
        cy.contains("Sign in")

        //Sign-in text is more than one, below one is uniquely identifying
        cy.contains('[status="warning"]',"Sign in")

        //traversing to parent and find out elements from different level
        cy.get('#inputEmail3')
        .parents('form')
        .find('button')
        .should('contain','Sign in')
        .parents('form')
        .find('nb-checkbox')
        .click()

        cy.contains('nb-card','Horizontal form').find('[type="email"]')
    

    })

    it('then and wrap methods', () => {

        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Form Layouts').click()
/*
        cy.contains('nb-card','Using the Grid').find('[for="inputEmail1"]').should('contain','Email')
        cy.contains('nb-card','Using the Grid').find('[for="inputPassword2"]').should('contain','Password')
        cy.contains('nb-card','Basic form').find('[for="exampleInputEmail1"]').should('contain','Email address')
        cy.contains('nb-card','Basic form').find('[for="exampleInputPassword1"]').should('contain','Password')
    */

       // cy.contains('nb-card','Using the Grid').then(function(firstForm)  {
        cy.contains('nb-card','Using the Grid').then(firstForm => {
             const firstFormEmail = firstForm.find('[for="inputEmail1"]').text();
             const firstFormPassword = firstForm.find('[for="inputPassword2"]').text();
             expect(firstFormEmail).to.equal('Email')
             expect(firstFormPassword).to.equal('Password')

            cy.contains('nb-card','Basic form').then(secondForm => {
                const secondFormPassword = secondForm.find('[for="exampleInputPassword1"]').text();
                expect(firstFormPassword).to.equal(secondFormPassword)

                //cypress way of query and not like above jquery
                cy.wrap(secondForm).find('[for="exampleInputPassword1"]').should('contain','Password')
            })
        })
    })

    it('then and wrap methods', () => {

        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Form Layouts').click()

        //1
        cy.get('[for="exampleInputEmail1"]').should('contain','Email address')

        //2
        cy.get('[for="exampleInputEmail1"]').then(label => {
            expect(label.text()).to.equal('Email address')
        })

        //3
        cy.get('[for="exampleInputEmail1"]').invoke('text').then(text => {
            expect(text).to.equal('Email address')
        })

        //invoke to verify checkbox selection
        cy.contains('nb-card','Basic form')
          .find('nb-checkbox')
          .click()
          .find('.custom-checkbox')
          .invoke('attr','class')
         // .should('contain','checked')    //one way to assert
          .then(classVal => {
              expect(classVal).to.contains('checked')
          })
    })
})
