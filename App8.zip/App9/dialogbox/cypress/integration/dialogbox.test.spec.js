/*///<reference types="cypress" />  */

describe('Dialog box', () => {   
   
    it('Browser dialog box', () => {
        cy.visit('/')
        cy.contains('Tables & Data').click()
        cy.contains('Smart Table').click()

        cy.get('tbody tr').first().find('.nb-trash').click()

        //Approach-1 (not good to confirm)
        cy.on('window:confirm',(confirm) => {
            expect(confirm).to.equal('Are you sure you want to delete?')
        })

        //Approach-2
        const stub = cy.stub()
        cy.on('window:confirm', stub)
        cy.get('tbody tr').first().find('.nb-trash').click().then(() => {
            expect(stub.getCall(0)).to.be.calledWith('Are you sure you want to delete?')
        })

        //Cancel the dialog
        cy.get('tbody tr').first().find('.nb-trash').click()
        cy.on('window:confirm',() => false)

    })

    it.only('Browser dialog box', () => {
        cy.visit('/')
        cy.contains('Modal & Overlays').click()
        cy.contains('Dialog').click()

        cy.contains('button', 'Open Dialog with component').click()
        .parents('nb-card')
        .get('nb-card-body')
        .should('contain','Lorem ipsum dolor sit amet')


        
    })
})
