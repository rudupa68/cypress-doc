/*///<reference types="cypress" />  */

describe('Tooltip test suite', () => {   
   
    it('tooltip test', () => {
        cy.visit('/')
        cy.contains('Modal & Overlays').click()
        cy.contains('Tooltip').click()

        cy.contains('nb-card','Colored Tooltips')
          .contains('Default').click()
       // cy.get('nb-tooltip').contains('This is a tooltip') //just to see it contains
        cy.get('nb-tooltip').should('contain','This is a tooltip')

    })
})
