/*///<reference types="cypress" />  */

describe('Datepicker test suite', () => {   
   
    it('date picker check plus some days of this month or immediate next month', () => {
        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Datepicker').click()

        let date = new Date()
        date.setDate(date.getDate() + 15)
        let futureDay = date.getDate()
        let futureMonth = date.toLocaleString('default',{month:'short'})



        cy.contains('nb-card','Common Datepicker')
          .find('input').then(input => {
              cy.wrap(input).click()

              cy.get('nb-calendar-navigation').invoke('attr','ng-reflect-date').then(dateAttr => {
                if(!dateAttr.includes(futureMonth)) {
                    cy.get('[data-name="chevron-right"]').click()
                    cy.get('nb-calendar-day-picker [class="day-cell ng-star-inserted"]').contains(futureDay).click()
                } else {
                    cy.get('nb-calendar-day-picker [class="day-cell ng-star-inserted"]').contains(futureDay).click()
                }
            })

            //  cy.get('nb-calendar-day-picker').contains('18').click()
            // cy.wrap(input).invoke('prop','value').should('contain','Mar 18, 2022')
          })
    })

    it('date picker check plus some days of this month or any future month', () => {
        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Datepicker').click()

        let date = new Date()
        date.setDate(date.getDate() + 55)
        let futureDay = date.getDate()
        let futureMonth = date.toLocaleString('default',{month:'short'})
        let dateAssert = futureMonth+' '+futureDay+', '+date.getFullYear()

        cy.contains('nb-card','Common Datepicker')
          .find('input').then(input => {
              cy.wrap(input).click()

              selectFromCurrentMonth()
              function selectFromCurrentMonth() {
                cy.get('nb-calendar-navigation').invoke('attr','ng-reflect-date').then(dateAttr => {
                    if(!dateAttr.includes(futureMonth)) {
                        cy.get('[data-name="chevron-right"]').click()
                        selectFromCurrentMonth()
                     //   cy.get('nb-calendar-day-picker [class="day-cell ng-star-inserted"]').contains(futureDay).click()
                    } else {
                        cy.get('nb-calendar-day-picker [class="day-cell ng-star-inserted"]').contains(futureDay).click()
                    }
                })
        }
             cy.wrap(input).invoke('prop','value').should('contain',dateAssert)
          })
    })

    it.only('organized the previous test-thats all', () => {

        function selectFromCurrentMonth(chosenDay) {
            let date = new Date()
            date.setDate(date.getDate() + chosenDay)
            let futureDay = date.getDate()
            let futureMonth = date.toLocaleString('default',{month:'short'})
            let dateAssert = futureMonth+' '+futureDay+', '+date.getFullYear()
    
            cy.get('nb-calendar-navigation').invoke('attr','ng-reflect-date').then(dateAttr => {
                if(!dateAttr.includes(futureMonth)) {
                    cy.get('[data-name="chevron-right"]').click()
                    selectFromCurrentMonth(chosenDay)
                 //   cy.get('nb-calendar-day-picker [class="day-cell ng-star-inserted"]').contains(futureDay).click()
                } else {
                    cy.get('nb-calendar-day-picker [class="day-cell ng-star-inserted"]').contains(futureDay).click()
                }
            })
            return dateAssert
        }

        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Datepicker').click()

        cy.contains('nb-card','Common Datepicker')
          .find('input').then(input => {
              cy.wrap(input).click()

              let dateAssert = selectFromCurrentMonth(77)

             cy.wrap(input).invoke('prop','value').should('contain',dateAssert)
             //cypress-assertion
             cy.wrap(input).should('have.value',dateAssert)
          })
    })
})
