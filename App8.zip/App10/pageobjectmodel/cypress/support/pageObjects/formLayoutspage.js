
export class FormLayoutPage {

    submitinlineFormWithNameAndEmail() {
        cy.contains('nb-card','Inline form').find('form').then( form => {
            cy.wrap(form).find('[placeholder="Jane Doe"]').type('raghuram bhat')
            cy.wrap(form).find('[placeholder="Email"]').type('raghu@test.com')
        })
    }
}

export const onFormLayoutsPage = new FormLayoutPage()