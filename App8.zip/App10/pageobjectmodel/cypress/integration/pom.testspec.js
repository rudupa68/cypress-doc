/*///<reference types="cypress" />  */

import { navigateTo } from "../support/pageObjects/navigationpage"

describe('Page Object Model', () => {   
   
    beforeEach('open application',() => {
        cy.visit('/')
    })

    it('navigation pages',() =>  {
        navigateTo.formsLayoutPage()
        navigateTo.datePickerPage()
        navigateTo.tablesPage()
        navigateTo.toolTipPage()
        navigateTo.toastrPage()
    })

})
