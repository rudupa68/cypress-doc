/*///<reference types="cypress" />  */

describe('Invoke test suite', () => {   
    it.only('invoke methods', () => {
        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Form Layouts').click()

        //1   //Refer to cypress assertions
        cy.get('[for="exampleInputEmail1"]')
          .should('contain','Email address')
          .should('have.class','label')
          .and('have.text','Email address')

        //2
        cy.get('[for="exampleInputEmail1"]').then(label => {
            expect(label.text()).to.equal('Email address')
            expect(label).to.have.class('label')
        })

        //3
        cy.get('[for="exampleInputEmail1"]').invoke('text').then(text => {
            expect(text).to.equal('Email address')
        })

        //invoke to verify checkbox selection
        cy.contains('nb-card','Basic form')
          .find('nb-checkbox')
          .click()
          .find('.custom-checkbox')
          .invoke('attr','class')
         // .should('contain','checked')    //one way to assert
          .then(classVal => {
              expect(classVal).to.contains('checked')
          })
    })
    
    it('assert input value', () => {
        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Datepicker').click()

        cy.contains('nb-card','Common Datepicker')
          .find('input').then(input => {
              cy.wrap(input).click()
              cy.get('nb-calendar-day-picker').contains('18').click()
              cy.wrap(input).invoke('prop','value').should('contain','Mar 18, 2022')
          })
    })
})
