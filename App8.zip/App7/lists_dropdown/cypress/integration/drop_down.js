/*///<reference types="cypress" />  */

describe('Drop down test suite', () => {   
    it('drop down input value', () => {
        cy.visit('/')
   
        cy.get('nav nb-select').click()
        cy.get('.options-list').contains('Dark').click()
        cy.get('nav nb-select').should('contain','Dark')
        cy.get('nb-layout-header nav').should('have.css','background-color','rgb(34, 43, 69)')
    })

    it.only('drop down input value', () => {
      cy.visit('/')

      cy.get('nav nb-select').then(dropdownlist => {
        cy.wrap(dropdownlist).click()
      //  cy.get('.options-list nb-option').each(listItem => {
        cy.get('.options-list nb-option').each((listItem,index) => {
          const itemText = listItem.text().trim()
          const colors = {
            "Light":"rgb(255, 255, 255)",
            "Dark":"rgb(34, 43, 69)",
            "Cosmic":"rgb(50, 50, 89)",
            "Corporate":"rgb(255, 255, 255)"
          }

          cy.wrap(listItem).click()
          cy.wrap(dropdownlist).should('contain',itemText)
          cy.get('nb-layout-header nav').should('have.css','background-color',colors[itemText])
          
          if (index < 3) {
            cy.wrap(dropdownlist).click()  // call this till last item
          }
        })
      })
    })

})
