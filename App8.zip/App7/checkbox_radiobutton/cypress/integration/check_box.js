/*///<reference types="cypress" />  */

describe('checkbox test suite', () => {   
    it.only('check box input value', () => {
        cy.visit('/')
        cy.contains('Modal & Overlays').click()
        cy.contains('Toastr').click()

      //  cy.get('[type="checkbox"]').check({force:true})  //will just check all of them
        cy.get('[type="checkbox"').eq(0).click({force:true})  //if you want to change status from check to uncheck
            
    })
})
