/*///<reference types="cypress" />  */

describe('Radio Button test suite', () => {   
    it.only('radio button input value', () => {
        cy.visit('/')
        cy.contains('Forms').click()
        cy.contains('Form Layouts').click()

        cy.contains('nb-card','Using the Grid')
          .find('[type="radio"]')
          .then(radiobuttons => {
            cy.wrap(radiobuttons)
              .first()
              .check({force: true})   //force cypress to check even if its hidden
              .should('be.checked')

            cy.wrap(radiobuttons)  
              .eq(1)      //selecting radio button by index - here its 2nd
              .check({force: true})

            cy.wrap(radiobuttons)  
            .eq(0)      //first button should now be unchecked
            .should('not.be.checked')

            cy.wrap(radiobuttons)  
            .eq(2)      //3rd button should be disabled
            .should('be.disabled')
          })            
    })
})
