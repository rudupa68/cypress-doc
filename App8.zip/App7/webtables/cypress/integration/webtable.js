/*///<reference types="cypress" />  */

describe('Web Table test suite', () => {   
    it('web table update existing row value', () => {
        cy.visit('/')
   
        cy.contains('Tables & Data').click()
        cy.contains('Smart Table').click()

        cy.get('tbody').contains('tr','Larry').then(tableRow => {
          cy.wrap(tableRow).find('.nb-edit').click()
          cy.wrap(tableRow).find('[placeholder="Age"]').clear().type('44')
          cy.wrap(tableRow).find('.nb-checkmark').click()
          cy.wrap(tableRow).find('td').eq(6).should('contain','44')        
        })
    })
    it('web table add new row value', () => {
      cy.visit('/')
 
      cy.contains('Tables & Data').click()
      cy.contains('Smart Table').click()

      cy.get('thead').find('.nb-plus').click()
      cy.get('thead').find('tr').eq(2).then(tablerows => {
        
        cy.wrap(tablerows).find('[placeholder="First Name"]').type("Raghav")
        cy.wrap(tablerows).find('[placeholder="Last Name"]').type("Raghav")
        cy.wrap(tablerows).find('[placeholder="Username"]').type("r_udupa")
        cy.wrap(tablerows).find('[placeholder="E-mail"]').type("rag1@gmail.com")
        cy.wrap(tablerows).find('[placeholder="Age"]').type("42")
        cy.wrap(tablerows).find('.nb-checkmark').click()
      })

      cy.get('tbody tr').first().find('td').then(tableColumns => {
          cy.wrap(tableColumns).eq(2).should('contain','Raghav')
          cy.wrap(tableColumns).eq(4).should('contain','r_udupa')
      })
          
      })

      it('web table search', () => {
        cy.visit('/')
   
        cy.contains('Tables & Data').click()
        cy.contains('Smart Table').click()

        cy.get('thead [placeholder="Age"]').type('20')
        cy.wait(500)
        cy.get('tbody tr').each(tableRow => {
          cy.wrap(tableRow).find('td').eq(6).should('contain','20')
        })

      })

      it('web table search iteratively', () => {
        cy.visit('/')
   
        cy.contains('Tables & Data').click()
        cy.contains('Smart Table').click()

        const age = [20,30,40,200]
        cy.wrap(age).each(age => {
          cy.get('thead [placeholder="Age"]').clear().type(age)
          cy.wait(500)
          cy.get('tbody tr').each(tableRow => {
            if (age == 200) {
              cy.wrap(tableRow).should('contain','No data found')
            } else {
              cy.wrap(tableRow).find('td').eq(6).should('contain',age)
            }
          })
        })


      })
  })
